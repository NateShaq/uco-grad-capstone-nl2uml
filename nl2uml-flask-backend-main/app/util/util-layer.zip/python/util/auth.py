import boto3
import os
import json

def get_user_claims(event):
    try:
        claims = event['requestContext']['authorizer']['claims']
        return {
            "sub": claims['sub'],
            "email": claims['email'],
            # Add any other claims you want to always grab
        }
    except (KeyError, TypeError):
        # Optionally, log or raise a custom exception here
        raise Exception("User claims missing from event")